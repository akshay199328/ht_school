<?php
	echo pmpro_shortcode_account('');
?>
