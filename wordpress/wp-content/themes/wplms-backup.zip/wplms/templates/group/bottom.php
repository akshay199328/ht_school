					<?php do_action( 'bp_after_group_home_content' ); ?>
					
				</div>
			</div><!-- .padder -->
		</div><!-- #container -->
	</div>
</section>	