<?php
/*
Plugin Name: WPLMS Demos
Plugin URI: http://www.VibeThemes.com
Description: WPLMS DEMOS by VibeThemes
Version: 1.6
Requires at least: WP 3.8, BuddyPress 1.9 
Tested up to: 2.0.1
License: (Themeforest License : http://themeforest.net/licenses)
Author: Mr.Vibe 
Author URI: http://www.VibeThemes.com
Network: true
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class wplms_demos_init{

	public static $instance;
    
    public static function init(){
    	
        if ( is_null( self::$instance ) )
            self::$instance = new wplms_demos_init();
        return self::$instance;
    }

	private function __construct(){
		$this->settings = array(
			array(
				'link'=>'https://demos.wplms.io/learningcenter/',
				'image'=>'https://vt-tfimages.s3.amazonaws.com/4.09-1.png',
				'name' => 'Learning Center'
			),
			array(
				'link'=>'https://demos.wplms.io/quizmaster',
				'image'=>'https://vt-tfimages.s3.amazonaws.com/4.09-3.png',
				'name' => 'Quiz Master'
			),
			array(
				'link'=>'https://demos.wplms.io/academy/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/academy.png',
				'name' => 'Academy Demo'
			),
			array(
				'link'=>'https://demos.wplms.io/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/base_demo.png',
				'name' => 'Base Demo'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo17/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo17.png',
				'name' => 'DEMO 17'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo16/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo16.png',
				'name' => 'DEMO 16'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo15/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo15.jpg',
				'name' => 'DEMO 15'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo14/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/wplms_demo14.jpg',
				'name' => 'DEMO 14'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo12/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/wplms_demo13.jpg',
				'name' => 'DEMO 13'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo12/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/wplms_demo12.jpg',
				'name' => 'DEMO 12'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo11/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/wplms_demo11.jpg',
				'name' => 'DEMO 11'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo10/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/wplms_demo10.jpg',
				'name' => 'DEMO 10'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo9/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo9.jpg',
				'name' => 'DEMO 9'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo8/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo8-550x1024-310x577-1.jpg',
				'name' => 'DEMO 8'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo7/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo7-554x1024-310x573-1.jpg',
				'name' => 'DEMO 7'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo6/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo6-310x431-1.jpg',
				'name' => 'DEMO 6'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo5/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo5-310x429-2.jpg',
				'name' => 'DEMO 5'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo4/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo4-310x463-2.jpg',
				'name' => 'DEMO 4'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo3/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo3-310x464-2.jpg',
				'name' => 'DEMO 3'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo2/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo2-310x463-2.jpg',
				'name' => 'DEMO 2'
			),
			array(
				'link'=>'https://demos.wplms.io/demos/demo1/',
				'image'=>'https://demos.wplms.io/academy/wp-content/uploads/2020/09/demo1-310x463-2.jpg',
				'name' => 'DEMO 1'
			),
		);
		
		add_action('wp_footer',array($this,'generate'));
	}	

	function generate(){
		
		$this->get_css();	
		$this->get_dom();
		$this->get_js();
	}

	function get_dom(){

		?>
		<div id="wplms_demos_slide_panel">
			<div class="wplms_demos">
				<span></span>
				<div class="title"> <a href="https://demos.wplms.io" target="_blank" style="font-size: 16px;color: #222;font-weight: 800;">WPLMS : LMS for WP</a><a href="http://themeforest.net/item/wplms-learning-management-system/6780226" class="buynow main">Buy Now</a></div>
				<div class="wplms_demo_container">
					<ul>
					<?php
						foreach($this->settings as $theme){
							echo '<li><a href="'.$theme['link'].'"><img src="'.$theme['image'].'" title="'.$theme['name'].'" /></a></li>';
						}
					?>
					</ul>
				</div>
			</div>
		</div>
		<?php
	}

	function get_css(){
		?>
		<style>
		#wplms_demos_slide_panel{
			position:fixed;
			top:150px;
			right:0;
			width:320px;
			height:calc(100% - 300px);
			background:#FFF;
			z-index:99;
			opacity:1;
			border-radius:0 0 0 5px;
			box-shadow: 0 1px 10px rgba(0,0,0,.2);
			transform: translate3d(320px, 0, 0);
			-webkit-transition: all 0.2s ease-in-out;
		    -moz-transition: all 0.2s ease-in-out;
		    -o-transition: all 0.2s ease-in-out;
	  	    transition: all 0.2s ease-in-out;
		}#wplms_demos_slide_panel .wplms_demo_container li a {
		    max-height: 120px;
		    overflow: hidden;
		    display: inline-block;
		    border-radius: 5px;
		}
		.wplms_demos{position:relative;}
		#wplms_demos_slide_panel.open{
			-webkit-transform: translate3d(0px, 0, 0);
			transform: translate3d(0px, 0, 0);
		}
		.title_content{padding: 0 15px 10px;font-size: 16px;line-height: 1.3;color:#fff;}
		#wplms_demos_slide_panel span{
			position:absolute;
			top:0;
			left:-40px;
			z-index:99;
			padding:11px;
			display:block;
			border-radius:2px 0 0 2px;
			background:#444;
			color:#FFF;line-height:1;
		}
		#wplms_demos_slide_panel span:after{
			content:"\e71e";font-family:'vicon';
			color:#FFF;line-height:1;
			font-size:20px;
		}
		#wplms_demos_slide_panel .title{
			padding:10px;
			text-align:center;
			font-size: 14px;font-weight:600;text-transform:uppercase;
		}

		#wplms_demos_slide_panel a.buynow{
		    padding: 5px 10px;
		    display: inline-block;
		    color: #FFF;
		    margin: -3px 0 0 10px;
		    border-radius: 4px;
		    font-size: 11px;
		    background: #82b440;
		    font-weight: 600;
		    float: right;
		    margin-top: -;
		    -webkit-box-shadow: 0 2px 0 #6f9a37;
		    box-shadow: 0 2px 0 #6f9a37;
		}
		#wplms_demos_slide_panel .wplms_demo_container{
			height:calc(100vh - 300px);
			background:#444;
			padding:10px;
			overflow-y:scroll;
		}

		#wplms_demos_slide_panel .wplms_demo_container ul{
		    display: grid;
		    grid-template-columns: 1fr 1fr;
		    grid-gap: 10px;
		    justify-content: space-evenly;
		}
		#wplms_demos_slide_panel .wplms_demo_container li:hover{
			box-shadow: 0 8px 20px 0 rgba(0,0,0,0.2);
		   -webkit-transform: perspective(400px) translateY(-2px);
		   -moz-transform: perspective(400px) translateY(-2px);
		   -o-transform: perspective(400px) translateY(-2px);
		   transform: perspective(400px) translateY(-2px);
		}
		</style>
		<?php
	}

	function get_js(){
		?>
		<script>
			document.addEventListener('DOMContentLoaded',function(){
				document.querySelector('#wplms_demos_slide_panel span').addEventListener('click',function(){
					document.querySelector('#wplms_demos_slide_panel').classList.toggle('open');
				});
			});
		</script>
		<?php
	}
}

add_action( 'init', 'wplms_demos_update');
function wplms_demos_update() {
	require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'update.php' );
	$config = array(
		'base'      => plugin_basename( __FILE__ ), //required
		'dashboard' => true,
		'repo_uri'  => 'https://wplms.io/',  //required
		'repo_slug' => 'wplms-demos',  //required
	);
	new WPLMS_Demos_Update( $config );
}

wplms_demos_init::init();	



